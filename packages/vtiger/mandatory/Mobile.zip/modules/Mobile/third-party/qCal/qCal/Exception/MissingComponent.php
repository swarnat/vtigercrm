<?php
class qCal_Exception_MissingComponent extends qCal_Exception {

	// represents an exception that is thrown when a component requires that another component be its child

}