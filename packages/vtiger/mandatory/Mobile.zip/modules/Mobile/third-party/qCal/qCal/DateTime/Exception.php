<?php
/**
 * qCal_Date is a sub-package of qCal, so it has its own exceptions.
 */
class qCal_DateTime_Exception extends qCal_Exception {

}